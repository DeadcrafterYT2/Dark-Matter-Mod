package org.darkmatter.dark_matter_domain.block;

import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.RegistryObject;
import org.darkmatter.dark_matter_domain.Dark_matter_domain;

import java.util.function.Supplier;

public class ModBlocks {
    // Hier verweisen wir auf die Blöcke aus der Hauptklasse
    public static Supplier<Block> DARK_MATTER_GENERATOR = () -> Dark_matter_domain.DARK_MATTER_GENERATOR.get();
    public static Supplier<Block> DARK_MATTER_STABILIZER = () -> Dark_matter_domain.DARK_MATTER_STABILIZER.get();
}