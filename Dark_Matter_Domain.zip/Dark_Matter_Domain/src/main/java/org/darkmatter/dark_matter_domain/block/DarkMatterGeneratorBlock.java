@Override
public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
    if (!level.isClientSide && hand == InteractionHand.MAIN_HAND) {
        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (blockEntity instanceof DarkMatterGeneratorBlockEntity generator) {
            player.sendSystemMessage(Component.literal("Dark Matter Generator - Energie: " + generator.getEnergy()));
        } else {
            player.sendSystemMessage(Component.literal("Generator block entity nicht gefunden"));
        }
    }
    return InteractionResult.SUCCESS;
}