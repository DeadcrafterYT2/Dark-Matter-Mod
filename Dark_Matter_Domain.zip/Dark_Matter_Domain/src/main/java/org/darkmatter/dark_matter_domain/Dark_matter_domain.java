package org.darkmatter.dark_matter_domain;

import com.mojang.logging.LogUtils;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.darkmatter.dark_matter_domain.block.entity.ModBlockEntities;
import org.slf4j.Logger;

@Mod(Dark_matter_domain.MODID)
public class Dark_matter_domain {
    public static final String MODID = "darkmattermod";
    private static final Logger LOGGER = LogUtils.getLogger();

    // Deferred Registers für Items und Blöcke
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    // Registrierung unserer Items
    public static final RegistryObject<Item> DARK_MATTER_STAR = ITEMS.register("dark_matter_star",
            () -> new Item(new Item.Properties()));

    // Registrierung unserer Blöcke
        public static final RegistryObject<Block> DARK_MATTER_STABILIZER = BLOCKS.register("dark_matter_stabilizer",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).requiresCorrectToolForDrops().strength(4.0F)));
    public static final RegistryObject<Block> DARK_MATTER_GENERATOR = BLOCKS.register("dark_matter_generator",
            () -> new DarkMatterGeneratorBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).requiresCorrectToolForDrops().strength(3.5F)));

    public Dark_matter_domain() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);

        modEventBus.addListener(this::addCreative);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(DARK_MATTER_STAR);
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(DARK_MATTER_GENERATOR_ITEM);
            event.accept(DARK_MATTER_STABILIZER_ITEM);
        }
    }
}