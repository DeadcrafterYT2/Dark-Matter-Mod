package org.darkmatter.dark_matter_domain.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class DarkMatterGeneratorBlockEntity extends BlockEntity {

    private int energy = 0;
    private final int MAX_ENERGY = 10000;

    public DarkMatterGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.DARK_MATTER_GENERATOR.get(), pos, state);
    }

    public int getEnergy() {
        return energy;
    }
}